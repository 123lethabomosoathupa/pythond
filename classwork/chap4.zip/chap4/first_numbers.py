# Use a for loop to print numbers from 1 to 4
# The range(1, 5) function generates numbers starting from 1 up to, but not including, 5
p
for value in range(1, 5):
    print(value)

# Create a list of numbers from 1 to 5 using the range() function
numbers = list(range(1, 6))


# Print the list of numbers
print(numbers)

# Print numbers from 1 to 5 using a for loop
for value in range(1, 6):
    print(value)
